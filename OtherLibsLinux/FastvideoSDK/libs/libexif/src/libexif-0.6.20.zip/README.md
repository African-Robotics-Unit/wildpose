libexif-0.6.20
==============

libexif version 0.6.20 for visual studio 2013
