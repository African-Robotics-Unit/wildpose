/* This file is generated automatically by configure */

//modified to not include stdint for visual studio builds

#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif
